@extends('layouts/app')
	
	@section('title')
		{!! $page->title !!}
	@endsection		
	@section('content')

		{!! $page->content !!}
	@endsection	