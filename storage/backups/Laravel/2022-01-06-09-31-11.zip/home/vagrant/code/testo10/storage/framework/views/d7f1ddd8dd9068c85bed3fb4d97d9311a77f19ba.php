	
	<?php $__env->startSection('title'); ?>
		<?php echo $page->title; ?>

	<?php $__env->stopSection(); ?>		
	<?php $__env->startSection('content'); ?>

		<?php echo $page->content; ?>

	<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/testo10/resources/views/pages/about_us.blade.php ENDPATH**/ ?>