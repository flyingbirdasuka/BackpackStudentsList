	<?php $__env->startSection('content'); ?>
			<ul class="breadcrumb">
				<li><a href="/students">All lessons</a></li>
			<?php if(count($lessons)>0): ?>	
				<?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				  <li><a href="<?php echo e($lesson->id); ?>"><?php echo e($lesson->lesson); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		<?php endif; ?>	

		<?php if($lesson_name): ?>
			<h2><?php echo e($lesson_name->lesson->lesson); ?></h2>
		<?php endif; ?>
			<div class="album py-5 bg-light">
		        	<div class="container">
		         		 <div class="row">    
							<?php if(count($students)>0): ?>
								<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-4">
										<div class="card" style="width: 18rem;">
										  <div class="card-body">
										    <h5 class="card-title"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h5>
										    <h6><a href="mailto:<?php echo e($student->email); ?>" class="card-link"><?php echo e($student->email); ?></a></h6>
										    <p class="card-text">Class: <?php echo e($student->lesson->lesson); ?></p>
										    <p class="card-text">Phone: <?php echo e($student->phone); ?></p>
										  </div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
				  		</div>
					</div>
			</div>	   	
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/testo10/resources/views/lesson.blade.php ENDPATH**/ ?>