<!-- This file is used to store topbar (left) items -->


<?php /**PATH /home/vagrant/code/testo10/resources/views/vendor/backpack/base/inc/topbar_left_content.blade.php ENDPATH**/ ?>